from app import db
from sqlalchemy.sql import text


def insertMenuItem(name, price):
    try:
        db.engine.execute(text('INSERT INTO MenuItem(name, price) VALUES(:name, :price)'), name=name, price=price)
    except Exception as e: print(e)

def updateMenuItem(id, name, price):
    try:
        db.engine.execute(text('UPDATE MenuItem SET name=:name, price=:price WHERE id=:id'), id=id, name=name, price=price)
    except Exception as e: print(e)

def deleteMenuItem(id):
    try:
        db.engine.execute(text('DELETE FROM MenuItem WHERE id=:id'), id=id)
    except Exception as e: print(e)

def getAllMenuItems():
    try:
        result = db.engine.execute(text('SELECT * FROM MenuItem;'))
        return list(result)
    except Exception as e: print(e)

def setup():
    try:
        db.engine.execute('''
            DROP TABLE IF EXISTS MenuItem;
        ''')
        db.engine.execute('''
            CREATE TABLE MenuItem(
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                name VARCHAR(255),
                price FLOAT
            );
        ''')
        insertMenuItem('pizza', 300)
    
    except Exception as e: print(e)
