from flask import render_template, flash, redirect, url_for, request
from app import app, dbQueries
from app.forms import LoginForm, AddMenuItemForm, UpdateMenuItemForm

@app.route('/')
@app.route('/index')
def index():
    user = {'username': 'Miguel'}
    posts = [
        {
            'author': {'username': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template('index.html', title='Home', user=user, posts=posts)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        flash('Login requested for user {}, remember_me={}'.format(
            form.username.data, form.remember_me.data))
        return redirect(url_for('index'))
    return render_template('login.html', title='Sign In', form=form)

@app.route('/menu')
def showMenu():
    return render_template('menu.html', title='Menu', items=dbQueries.getAllMenuItems())

@app.route('/menu/add', methods=['GET', 'POST'])
def addMenuItem():
    form = AddMenuItemForm()
    if form.validate_on_submit():
        data = form.data
        dbQueries.insertMenuItem(data['name'], data['price'])
        return redirect(url_for('showMenu'))
    return render_template('addMenuItem.html', title='Add Menu Item', form=form)

@app.route('/menu/remove')
def removeMenuItem():
    ID = request.args.get('id')
    dbQueries.deleteMenuItem(ID)
    return redirect(url_for('showMenu'))

@app.route('/menu/update', methods=['GET', 'POST'])
def updateMenuItem():
    ID = request.args.get('id')
    name = request.args.get('name')
    price = request.args.get('price')
    if not ID or not name or not price:
        return redirect(url_for('showMenu'))
    form = UpdateMenuItemForm()
    if form.validate_on_submit():
        data = form.data
        dbQueries.updateMenuItem(ID, data['name'], data['price'])
        return redirect(url_for('showMenu'))
    return render_template('updateMenuItem.html', title='Update Menu Item', form=form, name=name, price=price)


