from flask import Flask
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

app = Flask(__name__)
app.config.from_object(Config)
db = SQLAlchemy(app)
db.init_app(app)
with app.app_context():
    db.create_all()
migrate = Migrate(app, db)


from app import routes, dbQueries

dbQueries.setup()